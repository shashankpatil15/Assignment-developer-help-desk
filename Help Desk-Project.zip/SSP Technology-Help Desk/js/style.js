
"use strict"

function validationinquiry() {    
    var re=/^[\w]+$&*()-_=~`''"";:.,?/;
    if(form.fname.value == "" || !re.test(form.fname.value) || form.fname.value == form.lname.value){
        alert("1. Name is Required. 2. Symbol is not allow 3. Fist and last name should not equal");
    }

}